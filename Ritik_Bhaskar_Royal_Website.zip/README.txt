RITIK BHASKAR — ROYAL WEBSITE

HOW TO USE
1. Open index.html in a browser to preview the website.
2. The "Add My Photo" button previews a photo on your device. This preview is local and will not be saved to the public website automatically.
3. Edit index.html in any text/code editor to change the intro and social links.
4. To publish free with GitHub Pages:
   - Create/sign in to a GitHub account.
   - Create a repository named ritik-bhaskar-site.
   - Upload index.html.
   - In repository Settings > Pages, select deploy from the main branch/root and save.
   - GitHub will provide a public website address after publishing.
5. Replace the sample Instagram/YouTube/Facebook homepage links with your actual profile URLs before publishing.

NOTE
This is a ready-to-preview static website. It is not published online yet, and the public link will not exist until you host it.
